from aiogram import Bot, Dispatcher, executor
from aiogram import types
from aiogram.contrib.middlewares.logging import LoggingMiddleware
import datetime
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import sympy

from config import token_bot

import os
import shutil

bot = Bot(token=token_bot, parse_mode='html')
dp = Dispatcher(bot)
dp.middleware.setup(LoggingMiddleware())

allowed_users = [12345]
admin_users = [12345, 777000]
owner = [12345, 777000]

async def is_allowed(user_id):
    return user_id in allowed_users

# Обработчик команды /start
@dp.message_handler(commands=['start'])
async def start_bot(message: types.Message):
    await bot.send_message(message.from_user.id, "<b>Привет! Это бот для покупки <u>ирисок</u></b>\nДля оплаты и информации о ценах нажмите /help")

# Получение айди пользователя && чата
@dp.message_handler(commands=['ид'], content_types=types.ContentType.TEXT)
async def get_user_id(message: types.Message):
    if message.reply_to_message:
        user_id = message.reply_to_message.from_user.id
        await message.answer(f"🆔 пользователя равен: @<code>{user_id}</code>", parse_mode = 'HTML')
    else:
        chat_id = message.chat.id
        your_id = message.from_user.id
        await message.answer(f"🆔 данного чата равен: <code>{chat_id}</code>\nВаш: @<code>{your_id}</code>", parse_mode = 'HTML')

# Добавление админов овнером
@dp.message_handler(commands=['адм'])
async def adm_user(message: types.Message):
    if message.from_user.id in owner:
        user_id = message.get_args()
        admin_users.append(int(user_id))
        write_admin_list(admin_users)
        await message.answer(f"Теперь пользователь {user_id} является администратором бота.")

def write_admin_list(chat_id):
    with open('admin_list.txt', 'a') as file:
        current_time = datetime.datetime.now()
        file.write(f"admins: {admin_users}, был добавлен: {current_time}\n")

# Исключение админов овнером
@dp.message_handler(commands=['неадм'])
async def lock_user(message: types.Message):
    if message.from_user.id in owner:
        user_id = message.get_args()
        admin_users.remove(int(user_id))
        await message.answer(f"Пользователь {user_id} больше не имеет прав администратора.")

# Блокировка пользователей в боте
@dp.message_handler(commands=['лок'])
async def lock_user(message: types.Message):
    if message.from_user.id in admin_users:
        user_id = message.get_args()
        allowed_users.remove(int(user_id))
        await message.answer(f"Пользователь {user_id} заблокирован.")

# Добавление пользователей в список разрешенных
@dp.message_handler(commands=['доб'])
async def allow_user(message: types.Message):
    if message.from_user.id in admin_users:
        user_id = message.get_args()
        allowed_users.append(int(user_id))
        write_user_info(allowed_users)
        await message.answer(f"Пользователю {user_id} успешно выдан доступ! 🤝")

def write_user_info(user_id):
    with open('user_list.txt', 'a') as file:
        current_time = datetime.datetime.now()
        file.write(f"users: {allowed_users}, был добавлен: {current_time}\n")

# Обработчик сессии
@dp.message_handler(content_types=['document'])
async def download_session(message: types.Message):
    if not await is_allowed(message.from_user.id):
        await bot.send_message(message.from_user.id, "У вас нет разрешения на выполнение этой команды.")
        return
    msg = await bot.send_message(message.from_user.id, '<b>Обработка...</b>')

    name = message.document.file_name

	# Делаем проверку на правильность сессии (*.session)
    if name.split('.')[-1] != 'session':
        await bot.edit_message_text(chat_id = message.from_user.id,
									message_id = msg.message_id,
									text = f'🚫 <b>Вы отправили файл в формате "<code>.{name.split(".")[-1]}</code>"!</b>')
        return

	# Качаем сессию
    file_info = await bot.get_file(message.document.file_id)
    await bot.download_file(file_info.file_path, f'Session/{name}')

	# Отравляем TData
    tdata = await create_tdata(session_name=name)
    if tdata:
        with open(f"TData/{name.split('.')[0]}/tdata.zip", "rb") as file:
            await bot.send_document(message.from_user.id, file)

		# 2 вида удаления. У меня были проблемы с удалением папки TData, мол в доступе отказано. Я решил не заморачиваться и ебнуть os and shutil :3 
        os.remove(f"Session/{name}")
        shutil.rmtree(f"TData/{name.split('.')[0]}")
    else:
        await bot.send_message(message.from_user.id, '<b>Что-то пошло не так!\nВозможно сессия не валидная.')

@dp.message_handler(commands=['pay'])
async def show_commands(message: types.Message):
    if message.from_user.id in admin_users:
        await message.answer("<b>Для администраторов</b> \n<code>/Ид</code> - показывает ID пользователя(в ответ) и ID чата <code>\n/Доб</code> + ID - добавляет человека в список пользователей, у которых есть доступ к боту <code>\n/Лок</code> + ID - убирает человека из списка пользователей бота \n\n\n<b>Для Владельца</b> <code>\n/Адм</code> + ID - добавляет пользователя в список админов <code>\n/Неадм</code> + ID - убирает пользователя из списка админов")
    else:
        await bot.send_message(message.from_user.id, "Карта monobank: <code>5375 4114 2378 2429</code> \nКоментарий к платежу - ваш айди @<code>{your_id}</code> <b><u>в обязательном порядке</u></b>")

@dp.message_handler(commands=['help'])
async def show_main_menu(message: types.Message):
    await message.reply("Выберите пункт меню: \nДля вызова реквизитов, нажмите /pay", reply_markup=main_menu_keyboard())

def main_menu_keyboard():
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton(text="🧑🏻‍💻 Связаться с администратором бота", url="https://t.me/lloveari"))
    keyboard.add(InlineKeyboardButton(text="🥷🏻 Узнать прайс-лист ирисок", url="https://t.me/+HQn-Z1v9-UIyMGYy"))
    keyboard.add(InlineKeyboardButton(text="🤝 отзывы", url="https://t.me/shopsheed"))
    keyboard.add(InlineKeyboardButton(text="⚙️ Функционал бота", url="https://t.me/+pHSyEV5ibhozYWNi"))
    return keyboard

if __name__ == "__main__":
	executor.start_polling(dispatcher=dp,
						   skip_updates=True)